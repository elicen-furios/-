import React, {useEffect, useState} from "react";
import {createRoot} from "react-dom/client";
import "./style.css";

const API = (import.meta as any).env?.VITE_API_BASE_URL || "http://127.0.0.1:8000";
type Msg = {role:"user"|"assistant", text:string};

function App(){
  const [messages,setMessages] = useState<Msg[]>([
    {role:"assistant",text:"Namaste Akhil 👋 Main AKHIL PERSONAL AI ASSISTANT hoon. Aap kya karna chahte ho?"}
  ]);
  const [input,setInput]=useState("");
  const [online,setOnline]=useState(false);
  const [busy,setBusy]=useState(false);

  useEffect(()=>{fetch(API+"/health").then(r=>setOnline(r.ok)).catch(()=>setOnline(false));},[]);

  async function send(){
    const text=input.trim(); if(!text||busy)return;
    setInput(""); setMessages(m=>[...m,{role:"user",text}]); setBusy(true);
    try{
      const r=await fetch(API+"/chat",{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({message:text})});
      const d=await r.json();
      setMessages(m=>[...m,{role:"assistant",text:d.message||d.detail||"Request failed."}]);
    }catch{
      setMessages(m=>[...m,{role:"assistant",text:"Backend se connection nahi ho saka."}]);
    }finally{setBusy(false);}
  }

  return <div className="app">
    <aside>
      <div className="brand">AKHIL<br/><span>PERSONAL AI ASSISTANT</span></div>
      <nav>{["Chat","History","Memory","Tools","Devices","Permissions","Voice","Settings","About"].map(x=><button key={x}>{x}</button>)}</nav>
      <div className="status"><i className={online?"on":"off"}/>{online?"Online":"Offline"}</div>
    </aside>
    <main>
      <header><div><b>Assistant</b><small>{online?"Backend connected":"Backend offline"}</small></div></header>
      <section className="messages">
        {messages.map((m,i)=><div key={i} className={"msg "+m.role}><div>{m.text}</div></div>)}
        {busy&&<div className="msg assistant"><div>Processing…</div></div>}
      </section>
      <footer>
        <input value={input} onChange={e=>setInput(e.target.value)}
          onKeyDown={e=>e.key==="Enter"&&send()} placeholder="Type a command… e.g. Chrome kholo"/>
        <button onClick={send}>Send</button>
      </footer>
    </main>
  </div>
}
createRoot(document.getElementById("root")!).render(<App/>);
