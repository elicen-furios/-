package com.akhil.companion
import java.security.SecureRandom
import java.util.Base64

object SecureChannel {
    fun nonce(): String {
        val b=ByteArray(24)
        SecureRandom().nextBytes(b)
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b)
    }
}