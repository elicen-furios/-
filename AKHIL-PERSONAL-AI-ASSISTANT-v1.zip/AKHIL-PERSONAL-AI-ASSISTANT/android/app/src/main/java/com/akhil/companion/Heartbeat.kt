package com.akhil.companion

data class Heartbeat(
    val deviceId:String,
    val capabilities:List<String>,
    val timestampMs:Long=System.currentTimeMillis()
)