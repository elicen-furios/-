package com.akhil.companion

data class Capability(val id:String,val name:String,val risk:String,val enabled:Boolean)

object CapabilityCatalog {
    val baseline = listOf(
        Capability("device.battery","Battery status","low",true),
        Capability("device.info","Device information","low",true),
        Capability("microphone","Microphone","high",false),
        Capability("camera","Camera","high",false),
        Capability("notifications","Notification access","medium",false),
        Capability("screen_capture","Screen capture","high",false),
        Capability("location","Location","high",false)
    )
}