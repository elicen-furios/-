package com.akhil.companion

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("AKHIL PERSONAL AI ASSISTANT", style = MaterialTheme.typography.headlineSmall)
                    Text("Android Companion • Permission Center")
                    Button(onClick = { permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO)) }) {
                        Text("Enable microphone")
                    }
                    Button(onClick = { permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA)) }) {
                        Text("Enable camera")
                    }
                    Text("Sensitive capabilities are opt-in and use Android's official permission UI.")
                }
            }
        }
    }
}