package com.akhil.companion

data class PermissionState(
    val capabilityId:String,
    val purpose:String,
    val required:Boolean,
    val granted:Boolean,
    val lastVerified:Long?
)

object PermissionCenter {
    fun current() = CapabilityCatalog.baseline.map {
        PermissionState(it.id,it.name,false,it.enabled,null)
    }
}