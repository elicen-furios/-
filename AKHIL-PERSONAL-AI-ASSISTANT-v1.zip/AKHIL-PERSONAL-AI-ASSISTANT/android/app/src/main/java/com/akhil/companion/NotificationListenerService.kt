package com.akhil.companion
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotificationListenerService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // No secret forwarding. Notification access remains explicitly user-enabled.
    }
}