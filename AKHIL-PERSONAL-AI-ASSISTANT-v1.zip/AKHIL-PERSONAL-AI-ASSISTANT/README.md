# AKHIL PERSONAL AI ASSISTANT

Internal identifier: MYRAA.

This is a new implementation based on the supplied Grand Master Production Upgrade Prompt. The original third-party MYRAA source was not available, so this project does not claim to preserve private code from the APK.

## Backend
```bash
cd backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload --port 8000
```

## Frontend
```bash
cd frontend
npm install
npm run dev
```

## Security
Keep AI keys only in backend environment variables. Never ship them to React or Android.
Sensitive Android capabilities remain opt-in and use official Android permission/access flows.
