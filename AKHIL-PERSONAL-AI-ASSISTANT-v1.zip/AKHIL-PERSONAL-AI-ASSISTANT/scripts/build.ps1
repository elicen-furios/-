$ErrorActionPreference = "Stop"
Write-Host "=== AKHIL PERSONAL AI ASSISTANT BUILD ==="
Push-Location backend
python -m compileall app
Pop-Location
Push-Location frontend
npm install
npm run build
Pop-Location
if (Get-Command cargo -ErrorAction SilentlyContinue) {
  Push-Location desktop/src-tauri
  cargo check
  Pop-Location
}
Write-Host "Build validation completed."
