from .db import connect

def save(kind: str, content: str, importance: int = 50):
    with connect() as db:
        cur = db.execute(
            "INSERT INTO memories(kind,content,importance) VALUES(?,?,?)",
            (kind, content, importance)
        )
        return cur.lastrowid

def search(query: str, limit: int = 8):
    with connect() as db:
        rows = db.execute(
            "SELECT id,kind,content,importance,created_at,updated_at "
            "FROM memories ORDER BY importance DESC, updated_at DESC LIMIT 200"
        ).fetchall()
    terms = [x.lower() for x in query.split() if len(x) > 2]
    if not terms:
        return [dict(r) for r in rows[:limit]]
    scored = []
    for r in rows:
        text = (r["kind"] + " " + r["content"]).lower()
        score = sum(text.count(t) for t in terms)
        if score:
            scored.append((score, r["importance"], dict(r)))
    scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return [x[2] for x in scored[:limit]]

def delete(memory_id: int):
    with connect() as db:
        db.execute("DELETE FROM memories WHERE id=?", (memory_id,))
