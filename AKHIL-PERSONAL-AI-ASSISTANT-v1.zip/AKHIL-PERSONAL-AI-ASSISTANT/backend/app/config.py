from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "AKHIL PERSONAL AI ASSISTANT"
    app_env: str = "development"
    host: str = "127.0.0.1"
    port: int = 8000
    database_path: str = "./data/myraa.db"
    pairing_secret: str = "CHANGE_ME"
    ai_base_url: str | None = None
    ai_api_key: str | None = None
    ai_model: str | None = None

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
