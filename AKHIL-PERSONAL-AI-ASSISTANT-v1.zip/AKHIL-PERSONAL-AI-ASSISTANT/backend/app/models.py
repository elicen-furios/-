from pydantic import BaseModel, Field
from typing import Any

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=10000)
    conversation_id: str | None = None

class MemoryCreate(BaseModel):
    kind: str
    content: str
    importance: int = Field(default=50, ge=0, le=100)

class ToolRequest(BaseModel):
    tool_id: str
    arguments: dict[str, Any] = {}
    confirm: bool = False

class PairRequest(BaseModel):
    device_id: str
    name: str
    platform: str
    pairing_code: str

class HeartbeatRequest(BaseModel):
    device_id: str
    capabilities: list[str] = []
    latency_ms: int | None = None
