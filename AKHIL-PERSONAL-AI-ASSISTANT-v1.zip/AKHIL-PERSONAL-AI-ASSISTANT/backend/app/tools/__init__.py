from .registry import REGISTRY, list_tools
from . import windows
