import platform
import subprocess
import webbrowser
from pathlib import Path
from .registry import Tool, register

def _check_windows():
    if platform.system() != "Windows":
        return {"ok": False, "code": "E_PLATFORM", "message": "Windows automation is unavailable on this platform."}
    return None

def open_url(url: str):
    if not (url.startswith("https://") or url.startswith("http://")):
        return {"ok": False, "code": "E_INVALID_URL", "message": "Only HTTP(S) URLs are allowed."}
    err = _check_windows()
    if err: return err
    try:
        webbrowser.open(url, new=2)
        return {"ok": True, "message": "Browser navigation requested.", "verified": True}
    except Exception as e:
        return {"ok": False, "code": "E_EXECUTION", "message": str(e)}

def open_app(name: str):
    err = _check_windows()
    if err: return err
    aliases = {
        "chrome": ["cmd", "/c", "start", "", "chrome"],
        "notepad": ["notepad.exe"],
        "calculator": ["calc.exe"],
        "explorer": ["explorer.exe"],
        "settings": ["cmd", "/c", "start", "", "ms-settings:"],
    }
    key = name.strip().lower()
    if key not in aliases:
        return {"ok": False, "code": "E_UNSUPPORTED_APP", "message": f"Unsupported built-in app: {name}"}
    try:
        subprocess.Popen(aliases[key], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return {"ok": True, "message": f"{name} launch command completed.", "verified": True}
    except FileNotFoundError:
        return {"ok": False, "code": "E_APP_NOT_FOUND", "message": f"{name} is unavailable."}
    except Exception as e:
        return {"ok": False, "code": "E_EXECUTION", "message": str(e)}

def delete_file(path: str, confirm: bool = False):
    if not confirm:
        return {"ok": False, "code": "E_CONFIRMATION_REQUIRED", "message": "Deleting a file requires confirmation."}
    err = _check_windows()
    if err: return err
    p = Path(path).expanduser()
    if not p.is_file():
        return {"ok": False, "code": "E_NOT_FOUND", "message": "File does not exist."}
    try:
        p.unlink()
        return {"ok": True, "message": "File deleted.", "verified": not p.exists()}
    except Exception as e:
        return {"ok": False, "code": "E_DELETE_FAILED", "message": str(e)}

register(Tool("windows.browser.open_url","Open an HTTP(S) URL","windows","browser","browser_control","low",10,False,open_url))
register(Tool("windows.app.open","Open a supported Windows application","windows","applications","desktop_control","low",10,False,open_app))
register(Tool("windows.files.delete","Delete a file","windows","files","filesystem_delete","high",10,True,delete_file))
