from dataclasses import dataclass
from typing import Callable

@dataclass(frozen=True)
class Tool:
    id: str
    description: str
    platform: str
    capability: str
    permission: str | None
    risk: str
    timeout_s: float
    destructive: bool
    execute: Callable

REGISTRY: dict[str, Tool] = {}

def register(tool: Tool):
    REGISTRY[tool.id] = tool
    return tool

def list_tools():
    return [
        {
            "id": t.id,
            "description": t.description,
            "platform": t.platform,
            "capability": t.capability,
            "permission": t.permission,
            "risk": t.risk,
            "timeout_s": t.timeout_s,
            "destructive": t.destructive,
        } for t in REGISTRY.values()
    ]
