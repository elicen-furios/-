import re
from .memory import search
from .tools.registry import REGISTRY
from .db import connect

def audit(event_type, detail):
    with connect() as db:
        db.execute("INSERT INTO audit_events(event_type,detail) VALUES(?,?)", (event_type, detail))

def handle(message: str):
    text = message.strip()
    lower = text.lower()
    memories = search(text, 5)

    if re.search(r"\b(open|kholo|khol|start)\b", lower):
        for app in ("chrome", "notepad", "calculator", "explorer", "settings"):
            if app in lower:
                result = REGISTRY["windows.app.open"].execute(app)
                audit("tool_execution", f"windows.app.open ok={result.get('ok')}")
                return result.get("message", "Operation failed."), "windows.app.open", bool(result.get("verified"))

    m = re.search(r"(?:open|kholo|khol)\s+(https?://\S+)", text, re.I)
    if m:
        result = REGISTRY["windows.browser.open_url"].execute(m.group(1))
        audit("tool_execution", f"windows.browser.open_url ok={result.get('ok')}")
        return result.get("message", "Operation failed."), "windows.browser.open_url", bool(result.get("verified"))

    suffix = " I also found relevant memory." if memories else ""
    return f"Samajh gaya. Main request ko process karne ke liye ready hoon.{suffix}", None, False
