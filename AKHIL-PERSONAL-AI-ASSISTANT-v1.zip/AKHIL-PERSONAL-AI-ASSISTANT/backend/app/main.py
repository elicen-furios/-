from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime, timezone
import hashlib, hmac, json, secrets

from .config import settings
from .db import init_db, connect
from .models import ChatRequest, MemoryCreate, ToolRequest, PairRequest, HeartbeatRequest
from .memory import save, search, delete
from .tools import REGISTRY, list_tools
from .agent import handle

app = FastAPI(title=settings.app_name, version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173","http://127.0.0.1:5173","http://localhost:1420","http://127.0.0.1:1420"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"]
)

@app.on_event("startup")
def startup():
    init_db()

@app.get("/health")
def health():
    return {"ok": True, "service": settings.app_name, "time": datetime.now(timezone.utc).isoformat()}

@app.get("/status")
def status():
    with connect() as db:
        devices = [dict(x) for x in db.execute("SELECT * FROM devices ORDER BY name").fetchall()]
    return {"ok": True, "devices": devices}

@app.post("/chat")
def chat(req: ChatRequest):
    msg, tool, verified = handle(req.message)
    return {"ok": True, "message": msg, "tool_used": tool, "verified": verified}

@app.post("/memory")
def create_memory(req: MemoryCreate):
    return {"ok": True, "id": save(req.kind, req.content, req.importance)}

@app.get("/memory")
def get_memory(q: str = "", limit: int = 8):
    return {"ok": True, "items": search(q, max(1, min(limit, 50)))}

@app.delete("/memory/{memory_id}")
def remove_memory(memory_id: int):
    delete(memory_id)
    return {"ok": True}

@app.get("/tools")
def tools():
    return {"ok": True, "items": list_tools()}

@app.post("/tools/execute")
def execute_tool(req: ToolRequest):
    tool = REGISTRY.get(req.tool_id)
    if not tool:
        raise HTTPException(404, "Tool not found")
    if tool.destructive and not req.confirm:
        return {"ok": False, "code": "E_CONFIRMATION_REQUIRED", "message": "Confirmation required.", "tool": tool.id}
    try:
        result = tool.execute(**req.arguments)
    except Exception as e:
        result = {"ok": False, "code": "E_EXECUTION", "message": str(e)}
    with connect() as db:
        db.execute("INSERT INTO tool_executions(tool_id,ok,result_json) VALUES(?,?,?)",
                   (tool.id, int(bool(result.get("ok"))), json.dumps(result)))
    return result

def pair_digest(code: str):
    return hmac.new(settings.pairing_secret.encode(), code.encode(), hashlib.sha256).hexdigest()

@app.post("/devices/pair")
def pair(req: PairRequest):
    if len(req.pairing_code) < 6:
        return {"ok": False, "code": "E_INVALID_PAIRING_CODE", "message": "Pairing code is invalid."}
    token = secrets.token_urlsafe(32)
    digest = pair_digest(req.pairing_code)
    now = datetime.now(timezone.utc).isoformat()
    with connect() as db:
        db.execute("""INSERT INTO devices(id,name,platform,status,capabilities_json,last_seen)
                      VALUES(?,?,?,?,?,?)
                      ON CONFLICT(id) DO UPDATE SET name=excluded.name, platform=excluded.platform,
                      status='online', last_seen=excluded.last_seen""",
                   (req.device_id, req.name, req.platform, "online", "[]", now))
        db.execute("INSERT INTO audit_events(event_type,detail) VALUES(?,?)",
                   ("device_pairing", f"device={req.device_id} digest={digest[:12]}"))
    return {"ok": True, "device_id": req.device_id, "device_token": token}

@app.post("/devices/heartbeat")
def heartbeat(req: HeartbeatRequest):
    now = datetime.now(timezone.utc).isoformat()
    with connect() as db:
        cur = db.execute("UPDATE devices SET status='online',capabilities_json=?,last_seen=? WHERE id=?",
                         (json.dumps(req.capabilities), now, req.device_id))
    if cur.rowcount == 0:
        return {"ok": False, "code": "E_DEVICE_NOT_PAIRED", "message": "Device is not paired."}
    return {"ok": True, "status": "online", "last_seen": now}

@app.websocket("/ws/device")
async def device_ws(ws: WebSocket):
    await ws.accept()
    try:
        await ws.send_json({"type":"hello","service":settings.app_name})
        while True:
            msg = await ws.receive_json()
            if msg.get("type") == "heartbeat":
                await ws.send_json({"type":"heartbeat_ack","time":datetime.now(timezone.utc).isoformat()})
            elif msg.get("type") == "capabilities":
                await ws.send_json({"type":"capabilities_ack","capabilities":msg.get("capabilities",[])})
            else:
                await ws.send_json({"type":"error","code":"E_UNKNOWN_MESSAGE"})
    except WebSocketDisconnect:
        pass
